# Clio - Calcullator Learning Intelligence Operator 🤖📘

Clio es un agente pedagógico inteligente diseñado para enseñar cálculo usando el método socrático, adaptado a tres niveles de dificultad (básico, intermedio y avanzado). Incluye editor de ecuaciones, guía paso a paso, y genera un informe PDF personalizado con portada y comentario motivador.

## 🚀 Funcionalidades

- Detección automática del nivel del estudiante.
- Interacción socrática guiada por flujo pedagógico.
- Editor de ecuaciones integrado (MathLive).
- Resumen de aprendizaje con ejercicios y pasos.
- Descarga en PDF con:
  - Portada personalizada
  - Expresiones matemáticas
  - Comentario final de Clio

## 🛠️ Tecnologías

- React + Next.js
- Tailwind CSS
- MathLive
- jsPDF + autoTable
- Vercel (para despliegue gratuito)

## 🧪 Instalación local

1. Clona este repositorio:

```bash
git clone https://github.com/tu-usuario/clio-mvp.git
cd clio-mvp
```

2. Instala las dependencias:

```bash
npm install
```

3. Ejecuta el servidor de desarrollo:

```bash
npm run dev
```

4. Abre en el navegador:  
http://localhost:3000

## 🌐 Despliegue en Vercel (recomendado)

1. Crea una cuenta en https://vercel.com
2. Conecta tu repositorio desde GitHub
3. Vercel detectará automáticamente que es una app Next.js
4. Haz clic en **Deploy**

URL generada: `https://clio-mvp.vercel.app`

## 👩‍🎓 Créditos

Desarrollado por [Tu nombre o institución]  
Inspirado en 'Cálculo. Trascendentes tempranas' de James Stewart (7.ª ed.)

## 📝 Licencia

Este proyecto es de código abierto bajo licencia MIT.
